package sit.int204.final_088;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Final088Application {

    public static void main(String[] args) {
        SpringApplication.run(Final088Application.class, args);
    }

}
