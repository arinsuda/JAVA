package sit.int204.final_088;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Final088ApplicationTests {

    @Test
    void contextLoads() {
    }

}
